# Community Content Title
> Insert your content package title above.

### Name of Zip File
> Insert the name of your zip file above.

### Last Released:
> Insert the quarter and year the content was released e.g., 2023.Q3.

## What´s New
> __Optional__. In case of an update to this content package, state what´s new. 

## Descripton
> Introduce your content and state it´s business value. 

## Details
> __Optional__. What is included in this content package (in terms of stories, models..) 

## Connectivity
> Which backend connectivity does your package use. Does it use live or data aquisition (sample data)? 

## Download/Install Instructions
> __Optional__. Specific instructions how to download/install if general documenatntion does not cover this aspect.


## More Information
> __Optional__. Link here other sources of information regarding this package, if any.

## Contact
> __Optional__.State contact details e.g., OSS component, e-mail. 
